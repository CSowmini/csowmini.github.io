'use client';

import { motion } from 'framer-motion';
import { Send, Mail, Linkedin, Github } from 'lucide-react';

export default function Contact() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer group relative overflow-hidden"
    >
      {/* Messaging bubbles decoration */}
      <div className="absolute top-8 right-8 space-y-2">
        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.4 }}
          className="bg-blue-500 text-white px-4 py-2 rounded-2xl rounded-tr-sm text-xs ml-auto w-fit"
        >
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 bg-white rounded-full" />
            <div className="w-1.5 h-1.5 bg-white rounded-full" />
            <div className="w-1.5 h-1.5 bg-white rounded-full" />
          </div>
        </motion.div>
        
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.4 }}
          className="bg-blue-100 px-4 py-2 rounded-2xl rounded-tl-sm text-xs mr-auto w-fit"
        >
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full" />
          </div>
        </motion.div>

        <motion.div
          initial={{ x: 20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 1, duration: 0.4 }}
          className="bg-green-500 text-white px-4 py-2 rounded-2xl rounded-tr-sm text-xs ml-auto w-fit"
        >
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 bg-white rounded-full" />
            <div className="w-1.5 h-1.5 bg-white rounded-full" />
            <div className="w-1.5 h-1.5 bg-white rounded-full" />
          </div>
        </motion.div>

        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.4 }}
          className="bg-green-100 px-4 py-2 rounded-2xl rounded-tl-sm text-xs mr-auto w-fit"
        >
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
          </div>
        </motion.div>
      </div>

      <div className="relative z-10">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center group-hover:bg-blue-50 transition-colors">
            <Send className="w-6 h-6 text-gray-700 group-hover:text-blue-600" />
          </div>
        </div>
        
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">Contact</h2>
        <p className="text-gray-600 mb-6">Email, LinkedIn, carrier pigeon...</p>
        
        <div className="space-y-3">
          <a 
            href="mailto:your.email@example.com"
            className="flex items-center gap-3 text-gray-700 hover:text-blue-600 transition-colors"
          >
            <Mail className="w-5 h-5" />
            <span className="text-sm">Email</span>
          </a>
          
          <a 
            href="https://linkedin.com/in/yourprofile"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 text-gray-700 hover:text-blue-600 transition-colors"
          >
            <Linkedin className="w-5 h-5" />
            <span className="text-sm">LinkedIn</span>
          </a>
          
          <a 
            href="https://github.com/yourprofile"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 text-gray-700 hover:text-blue-600 transition-colors"
          >
            <Github className="w-5 h-5" />
            <span className="text-sm">GitHub</span>
          </a>
        </div>
      </div>
    </motion.div>
  );
}
