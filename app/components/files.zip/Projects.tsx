'use client';

import { motion } from 'framer-motion';
import { Folder, Database, BarChart3, Brain, TrendingUp } from 'lucide-react';

export default function Projects() {
  const projectIcons = [
    { Icon: Database, color: 'bg-blue-500', name: 'ETL Pipeline' },
    { Icon: BarChart3, color: 'bg-purple-500', name: 'Dashboards' },
    { Icon: Brain, color: 'bg-green-500', name: 'ML Models' },
    { Icon: TrendingUp, color: 'bg-orange-500', name: 'Forecasting' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer group"
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center group-hover:bg-blue-50 transition-colors">
          <Folder className="w-6 h-6 text-gray-700 group-hover:text-blue-600" />
        </div>
      </div>
      
      <h2 className="text-2xl font-semibold text-gray-900 mb-2">Projects</h2>
      <p className="text-gray-600 mb-6">Personal projects I&apos;ve been working on.</p>
      
      <div className="flex gap-3 flex-wrap">
        {projectIcons.map(({ Icon, color, name }, index) => (
          <motion.div
            key={name}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 + index * 0.1 }}
            className={`w-16 h-16 ${color} rounded-2xl flex items-center justify-center shadow-md hover:shadow-lg transition-all hover:scale-110 cursor-pointer`}
            title={name}
          >
            <Icon className="w-8 h-8 text-white" />
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
