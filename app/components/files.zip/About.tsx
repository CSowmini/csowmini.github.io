'use client';

import { motion } from 'framer-motion';
import { User } from 'lucide-react';

export default function About() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer group"
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center group-hover:bg-blue-50 transition-colors">
          <User className="w-6 h-6 text-gray-700 group-hover:text-blue-600" />
        </div>
      </div>
      
      <h2 className="text-2xl font-semibold text-gray-900 mb-2">About</h2>
      <p className="text-gray-600 leading-relaxed">
        Data Analyst with 4+ years of experience transforming complex data into actionable insights. 
        MS in Data Science from Indiana University. Specialized in statistical modeling, visualization, 
        and strategic analytics across public health, sports, energy, and consulting sectors.
      </p>
    </motion.div>
  );
}
