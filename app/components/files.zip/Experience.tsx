'use client';

import { motion } from 'framer-motion';
import { Briefcase } from 'lucide-react';
import Image from 'next/image';

export default function Experience() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer group relative overflow-hidden"
    >
      {/* Illustration - placeholder for now */}
      <div className="absolute bottom-0 right-0 w-40 h-40 opacity-10">
        <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-400 rounded-full blur-2xl" />
      </div>

      <div className="relative z-10">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center group-hover:bg-blue-50 transition-colors">
            <Briefcase className="w-6 h-6 text-gray-700 group-hover:text-blue-600" />
          </div>
        </div>
        
        <h2 className="text-2xl font-semibold text-gray-900 mb-2">Work Experience</h2>
        <p className="text-gray-600 mb-4">My career as a Data Analyst.</p>
        
        <div className="space-y-3">
          <div className="border-l-2 border-blue-500 pl-4">
            <h3 className="font-semibold text-gray-900">Data Analyst</h3>
            <p className="text-sm text-gray-600">Delineate • Current</p>
          </div>
          
          <div className="border-l-2 border-gray-300 pl-4">
            <h3 className="font-semibold text-gray-900">Sports Analytics</h3>
            <p className="text-sm text-gray-600">Pacers Sports & Entertainment</p>
          </div>
          
          <div className="border-l-2 border-gray-300 pl-4">
            <h3 className="font-semibold text-gray-900">Public Health Analyst</h3>
            <p className="text-sm text-gray-600">Indiana Department of Health</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
