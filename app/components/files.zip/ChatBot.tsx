'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send } from 'lucide-react';

export default function ChatBot() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Array<{ type: 'user' | 'bot', text: string }>>([]);

  const quickQuestions = [
    "Who is Chandrika?",
    "What is her experience?",
    "Which tools does she use?",
    "What are her specialties?",
    "How can I contact her?"
  ];

  const handleQuickQuestion = (question: string) => {
    setInput(question);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Add user message
    const userMessage = { type: 'user' as const, text: input };
    setMessages(prev => [...prev, userMessage]);

    // Simple bot responses based on keywords
    let botResponse = "Thanks for your question! For detailed information, please check the sections above or reach out via the Contact card.";

    if (input.toLowerCase().includes('who') || input.toLowerCase().includes('chandrika')) {
      botResponse = "I'm Chandrika, a Data Analyst with 4+ years of experience. I specialize in statistical modeling, data visualization, and turning complex data into actionable insights across healthcare, sports analytics, and consulting.";
    } else if (input.toLowerCase().includes('experience')) {
      botResponse = "I have 4+ years of experience working at Delineate, with previous roles at Pacers Sports & Entertainment, Indiana Department of Health, MISO, and Deloitte. I hold an MS in Data Science from Indiana University.";
    } else if (input.toLowerCase().includes('tools') || input.toLowerCase().includes('skills')) {
      botResponse = "I work with Python, R, SQL, Tableau, Power BI, Azure, Databricks, and various ML libraries. I'm certified in Databricks Data Engineer Associate and Data Visualization with Tableau.";
    } else if (input.toLowerCase().includes('speciali')) {
      botResponse = "My specialties include statistical modeling, predictive analytics, data visualization, ETL pipeline development, and creating dashboards that drive decision-making. I focus on healthcare and mission-driven organizations.";
    } else if (input.toLowerCase().includes('contact')) {
      botResponse = "You can reach me via email, LinkedIn, or GitHub - all links are available in the Contact card above!";
    }

    // Add bot response after a short delay
    setTimeout(() => {
      setMessages(prev => [...prev, { type: 'bot', text: botResponse }]);
    }, 500);

    setInput('');
  };

  return (
    <section className="max-w-4xl mx-auto px-6 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="bg-white rounded-3xl shadow-lg p-8"
      >
        <h2 className="text-3xl font-semibold text-center text-gray-900 mb-2">
          Ask ChandrikaGPT
        </h2>
        <p className="text-center text-gray-600 mb-8">
          What would you like to know?
        </p>

        {/* Quick Questions */}
        <div className="flex flex-wrap gap-3 justify-center mb-8">
          {quickQuestions.map((question) => (
            <button
              key={question}
              onClick={() => handleQuickQuestion(question)}
              className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-full text-sm text-gray-700 transition-colors"
            >
              {question}
            </button>
          ))}
        </div>

        {/* Messages */}
        <div className="mb-6 space-y-4 min-h-[200px] max-h-[400px] overflow-y-auto">
          <AnimatePresence>
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                    message.type === 'user'
                      ? 'bg-blue-600 text-white rounded-br-sm'
                      : 'bg-gray-100 text-gray-900 rounded-bl-sm'
                  }`}
                >
                  {message.text}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="What would you like to know?"
            className="w-full px-6 py-4 pr-14 border-2 border-gray-200 rounded-full focus:outline-none focus:border-blue-500 transition-colors"
          />
          <button
            type="submit"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-gradient-to-r from-amber-600 to-amber-700 rounded-full flex items-center justify-center hover:from-amber-700 hover:to-amber-800 transition-all shadow-md hover:shadow-lg"
          >
            <Send className="w-5 h-5 text-white" />
          </button>
        </form>
      </motion.div>
    </section>
  );
}
