'use client';

import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="pt-24 pb-12 px-6">
      <div className="max-w-6xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-6xl md:text-7xl font-serif font-light text-gray-900 mb-4">
            Chandrika
          </h1>
          <p className="text-xl text-gray-600">
            Data Analyst
          </p>
        </motion.div>
      </div>
    </section>
  );
}
